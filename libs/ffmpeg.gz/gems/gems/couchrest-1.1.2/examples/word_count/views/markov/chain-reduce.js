function(key,vs,c){
  if (c) {
    return sum(vs);
  } else {
    return vs.length;
  }
}