function globalLib() {
  return "fixture";
};