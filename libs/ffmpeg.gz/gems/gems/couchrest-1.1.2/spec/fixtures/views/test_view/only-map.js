function(doc) {
  //include-lib
  emit(null, null);
};