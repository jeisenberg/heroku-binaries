CouchRest THANKS
=====================

CouchRest was originally developed by J. Chris Anderson <jchris@grabb.it>
and a number of other contributors. Many people further contributed to 
CouchRest by reporting problems, suggesting various improvements or submitting
changes. A list of these people is included below.

 * [Matt Aimonetti](http://merbist.com/about/)
 * [Greg Borenstein](http://ideasfordozens.com)
 * [Geoffrey Grosenbach](http://nubyonrails.com/)
 * [Jonathan S. Katz](http://github.com/jkatz)
 * [Matt Lyon](http://mattly.tumblr.com/)
 * Simon Rozet (simon /at/ rozet /dot/ name)
 * [Marcos Tapajós](http://tapajos.me)
 * [Sam Lown](http://github.com/samlown)
 * [Will Leinweber](http://github.com/will)
 
Patches are welcome. The primary source for this software project is [on Github](http://github.com/couchrest/couchrest)

A lot of people have active forks - thank you all - even the patches I don't end up using are helpful.